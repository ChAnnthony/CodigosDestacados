export interface Autor {
    id: number;
    dni: string;
    nombres: string;
    apellidos: string;
    fecha_nacimiento: string;
    pais: string;
}