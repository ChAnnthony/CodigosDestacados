export interface Libro {
    id: number;
    titulo: string;
    id_autor: number;
    editorial: string;
    nropaginas: number;
    stock: number;
    estado: string;
}