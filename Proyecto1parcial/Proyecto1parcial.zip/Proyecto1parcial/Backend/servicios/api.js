// frontend/api.js
export function getProducts() {
  return fetch('http://localhost:3000/products').then(response => response.json());
}

export function getEmployees() {
  return fetch('http://localhost:3000/employees').then(response => response.json());
}

export function addProduct(product) {
  return fetch('http://localhost:3000/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product)
  });
}

export function addEmployee(employee) {
  return fetch('http://localhost:3000/employees', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(employee)
  });
}

// Import components
import '../../Fronkend/components/Header.js';
import '../../Fronkend/components/Footer.js';
import '../../Fronkend/components/ProducE.js';
import '../../Fronkend/components/Employe.js';
import '../../Fronkend/components/MostrarPE.js';
import '../../Fronkend/components/MostrarTabla.js';