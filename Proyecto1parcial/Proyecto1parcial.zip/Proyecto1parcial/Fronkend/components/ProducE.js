import { addProduct } from '../../Backend/servicios/api.js'; 

class ProductForm extends HTMLElement {
  constructor() {
    super();
    this.shadow = this.attachShadow({ mode: 'open' });
    const template = document.createElement('template');
    template.innerHTML = `
      <style>
        :host {
          display: block;
        }
        form {
          max-width: 300px;
          display: flex;
          flex-direction: column;
        }
        input, button {
          padding: 10px;
          margin-bottom: 10px;
          font-size: 1rem;
        }
        button {
          background-color: green;
          color: white;
          cursor: pointer;
          border: none;
        }
        button:hover {
          background-color: darkgreen;
          color: white;
        }
      </style>
      <form id="product-form">
        <input type="text" name="name" id="name" placeholder="Nombre" required>
        <input type="number" name="price" id="price" placeholder="Precio" required>
        <button type="submit">Agregar Producto</button>
      </form>
    `;
    this.shadow.appendChild(template.content.cloneNode(true));
  }

  connectedCallback() {
    this.handleSubmit = (event) => {
      event.preventDefault();
      const name = this.shadow.querySelector('#name').value;
      const price = this.shadow.querySelector('#price').value;

      addProduct({ name, price }) 
        .then(() => {
          alert('Producto registrado');
          this.clearForm();
          document.querySelector('product-table').fetchProducts(); 
        })
        .catch(error => console.error('Error:', error));
    };

    this.shadow.querySelector('#product-form').addEventListener('submit', this.handleSubmit);
  }

  disconnectedCallback() {
    this.shadow.querySelector('#product-form').removeEventListener('submit', this.handleSubmit);
  }

  clearForm() {
    this.shadow.querySelector('#name').value = '';
    this.shadow.querySelector('#price').value = '';
  }
}

customElements.define('product-form', ProductForm);
