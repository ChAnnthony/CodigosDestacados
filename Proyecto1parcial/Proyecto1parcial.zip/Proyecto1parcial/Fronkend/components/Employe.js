import { addEmployee } from '../../Backend/servicios/api.js'; 

class EmployeeForm extends HTMLElement {
  constructor() {
    super();

    this.shadow = this.attachShadow({ mode: 'open' });
    const template = document.createElement('template');
    template.innerHTML = `
      <style>
        :host {
          display: block;
        }
        form {
          max-width: 300px;
          display: flex;
          flex-direction: column;
        }
        input, button {
          padding: 10px;
          margin-bottom: 10px;
          font-size: 1rem;
        }
        button {
          background-color: blue;
          color: white;
          cursor: pointer;
          border: none;
        }
        button:hover {
          background-color: darkblue;
        }
      </style>
      <form id="employee-form">
        <input type="text" name="name" id="name" placeholder="Nombre" required>
        <input type="text" name="position" id="position" placeholder="Puesto" required>
        <button type="submit">Agregar Empleado</button>
      </form>
    `;
    this.shadow.appendChild(template.content.cloneNode(true));
  }

  connectedCallback() {
    this.handleSubmit = (event) => {
      event.preventDefault();
      const name = this.shadow.querySelector('#name').value;
      const position = this.shadow.querySelector('#position').value;

      addEmployee({ name, position }) // Usa la función importada addEmployee
        .then(() => {
          alert('Empleado registrado');
          this.limpiarFormulario();
          document.querySelector('employee-table').fetchEmployees();
        })
        .catch(error => console.error('Error:', error));
    };

    this.shadow.querySelector('#employee-form').addEventListener('submit', this.handleSubmit);
  }

  disconnectedCallback() {
    this.shadow.querySelector('#employee-form').removeEventListener('submit', this.handleSubmit);
  }

  limpiarFormulario() {
    this.shadow.querySelector('#name').value = '';
    this.shadow.querySelector('#position').value = '';
  }
}

customElements.define('employee-form', EmployeeForm);
