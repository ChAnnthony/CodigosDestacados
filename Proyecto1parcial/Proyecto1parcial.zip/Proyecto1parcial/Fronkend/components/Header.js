class AppHeader extends HTMLElement {
    constructor() {
      super();
      const shadow = this.attachShadow({ mode: 'open' });
      shadow.innerHTML = `
        <style>
          header {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 1rem;
          }
        </style>
        <header>
          <h1>Proyecto Final – Parcial 1</h1>
        </header>
      `;
    }
  }
  customElements.define('app-header', AppHeader);
  